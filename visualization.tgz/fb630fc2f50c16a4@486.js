function _1(md){return(
md`# Replication Proposal Vast 2025
`
)}

function _aliasData(FileAttachment){return(
FileAttachment("alias_similarity_graph@7.json").json()
)}

async function _heatmapData(FileAttachment)
{
  const raw = await FileAttachment("temporal_heatmap@1.json").json();

  return Object.keys(raw.entity).map(i => ({
      entity: raw.entity[i],
      hour: raw.hour[i],
      activity: raw.activity[i]
    }))
}


function _timelineData(FileAttachment){return(
FileAttachment("communication_timeline.json").json()
)}

function _coordinationData(FileAttachment){return(
FileAttachment("temporal_coordination.json").json()
)}

function _sequenceData(FileAttachment){return(
FileAttachment("communication_sequences.json").json()
)}

function _profileData(FileAttachment){return(
FileAttachment("behavior_profiles@3.json").json()
)}

async function _semanticData(FileAttachment)
{
  const raw = await FileAttachment("semantic_projection.json").json();

  return Object.entries(raw).map(([id, [x, y]]) => ({
    id,
    x,
    y
  }))
}


function _egoData(FileAttachment){return(
FileAttachment("ego_networks.json").json()
)}

function _selectedEntity(){return(
'Sam'
)}

function _currentTimelineTime(){return(
new Date("2025-01-01T00:00:00")
)}

function _getNeighbors(){return(
(entityId, links) => {
  if (!entityId) return new Set();
  const neighbors = new Set();
  links.forEach(l => {
    const sourceId = typeof l.source === 'object' ? l.source.id : l.source;
    const targetId = typeof l.target === 'object' ? l.target.id : l.target;
    if (sourceId === entityId) neighbors.add(targetId);
    if (targetId === entityId) neighbors.add(sourceId);
  });
  neighbors.add(entityId); // Include self
  return neighbors;
}
)}

function _temporalClusteredEntities(d3,heatmapData)
{
  const entityProfiles = d3.rollups(
    heatmapData,
    v => {
      const maxActivity = d3.max(v, d => d.activity);
      const peakHourObj = v.find(d => d.activity === maxActivity);
      return peakHourObj ? peakHourObj.hour : 0;
    },
    d => d.entity
  );
  
  // Sort by peak hour, then alphabetically as fallback
  return entityProfiles
    .sort((a, b) => a[1] - b[1] || a[0].localeCompare(b[0]))
    .map(d => d[0]);
}


function _profileMap(profileData){return(
new Map(profileData.map(d => [d.id, d]))
)}

function _similarityRoundView(drawSimilarityRound,aliasData){return(
drawSimilarityRound (aliasData, 1000, 900)
)}

function _drawSimilarityRound(d3){return(
(data, width, height) => {
  const radius = Math.min(width, height) / 2;
  const labelMargin = 20;

  const svg = d3.create('svg')
      .attr('width', width)
      .attr('height', height)
      //.attr('viewBox', [-radius, -radius, width, width])
      .attr('viewBox', [0, 0, width, height])
      //.attr("preserveAspectRatio", "xMidYMid meet")

  const g = svg.append('g')
    .attr('transform', `translate(${width / 2}, ${height / 2})`);

  const colorScale = d3.scaleOrdinal()
      .domain(['Person', 'Vessel', 'Location', 'Organization', 'Group'])
      .range(['#4A81BA', '#E78523', '#5E9F37', '#C0392B', '#8E44AD']); 

  
  // Agrupamos los nodos por tipo
  const nested = d3.group(data.nodes, d => d.type);
  
  // Creamos la jerarquía
  const root = d3.hierarchy({
    children: Array.from(nested, ([key, value]) => ({name: key, children: value}))
  });
  
  // El cluster calcula ángulos (0-360) y radios
  const cluster = d3.cluster()
      .size([360, radius * 0.82]);
  
  cluster(root);

  // Lineas
  
  const lineGen = d3.lineRadial()
      .angle(d => d.x * Math.PI / 180) // Convierte grados a radianes
      .radius(d => d.y)               // La distancia al centro
      .curve(d3.curveBundle.beta(0.1)); // Qué tan "curva" es la conexión?

  // Mapeo
  const idToNode = new Map(root.leaves().map(d => [d.data.id, d]));
  const priority = {
    Low: 0,
    Medium: 1,
    High: 2
  };

  const sortedLinks = [...data.links].sort(
    (a, b) => priority[a.similarity] - priority[b.similarity]
  );
  g.append('g')
    .selectAll('path')
    .data(sortedLinks)
    .join('path')
      .attr('d', d => {
        const start = idToNode.get(d.source.id);
        const end = idToNode.get(d.target.id);
        // .path(end) genera los puntos intermedios para que se vea más como el paper
        return lineGen(start.path(end));
      })
      .attr('fill', 'none')
      .attr('stroke', d => {
        const similarity = d.similarity;
        if (similarity == 'High') return '#810f7c';
        if (similarity == 'Medium') return '#9ebcda';
        return '#8c96c6'
      })
      .attr('stroke-width',  d => {
        const similarity = d.similarity;
        if (similarity == 'High') return 1;
        if (similarity == 'Medium') return 1;
        return 0.05
      })
      .attr('stroke-opacity', 1);
  
  const nodeGroups = g.append('g')
    .selectAll('g')
    .data(root.leaves())
    .join('g')
      // Para rotar cada grupo según su ángulo y lo moverlo hacia afuera
      .attr('transform', d => `rotate(${d.x - 90}) translate(${d.y},0)`);

  nodeGroups.append('path')
      .attr('d', d3.symbol()
          //.type(d => d.data.is_pseudonym ? d3.symbolStar : d3.symbolCircle)
          .size(50)) // Tamaño un poco más grande
      .attr('fill', d => colorScale(d.data.type)) // Usamos la escala de colores
      .attr('stroke', '#333')
      .attr('stroke-width', 1.5);
  
  // Texto
  nodeGroups.append('text')
      .attr('dy', '0.31em')
    //.attr('x', d => d.x < 180 ? 6 : -6)
      .attr('x', d => d.x < 180 ? 12 : -12)
      .attr('text-anchor', d => d.x < 180 ? 'start' : 'end')  // ifs con "?"
      .attr('transform', d => d.x >= 180 ? 'rotate(180)' : null)
      .text(d => d.data.id)
    //.attr('font-size', '10px')
      .attr('font-size', '8px')
      .attr('font-family', 'sans-serif');

  const legend = svg.append('g')
      // Posicionamos en la esquina superior izquierda (-radius) más un pequeño margen (20px)
    //.attr('transform', `translate(${-radius + 20}, ${-radius + 20})`)
      .attr('transform', `translate(20, 20)`)
      .attr('font-family', 'sans-serif')
      .attr('font-size', '12px')
      .attr('fill', '#333');
  
  // Círculo
  legend.append('path')
      .attr('d', d3.symbol().type(d3.symbolCircle).size(60)())
      .attr('transform', 'translate(10, 10)')
      .attr('fill', 'none')
      .attr('stroke', '#333')
      .attr('stroke-width', 1.5);
  legend.append('text').attr('x', 30).attr('y', 14).text('Real Name');

  // Leyenda 
  const categories = ['Person', 'Vessel', 'Location', 'Organization', 'Group'];
  
  const legendColors = legend.selectAll('.cat')
      .data(categories)
      .join('g')
      .attr('class', 'cat')
      .attr('transform', (d, i) => `translate(0, ${65 + i * 22})`);

  legendColors.append('rect')
      .attr('x', 4)
      .attr('y', -6)
      .attr('width', 12)
      .attr('height', 12)
      .attr('fill', d => colorScale(d));

  legendColors.append('text')
      .attr('x', 30)
      .attr('y', 5)
      .text(d => d);

  return svg.node();
}
)}

function _similarityTemporalHeatMapView(drawTemporalHeatmap,heatmapData,temporalClusteredEntities){return(
drawTemporalHeatmap(heatmapData, temporalClusteredEntities)
)}

function _drawTemporalHeatmap(d3,$0){return(
(data, sortedEntities) => {
  const margin = { top: 20, right: 5, bottom: 5, left: 100 };
  const w = 900, h = Math.max(1200, sortedEntities.length * 10);
  
  const svg = d3
    .create("svg")
    .attr("height", h)
    .attr("width", w)
  
  const x = d3.scaleLinear().domain([1, 25]).range([margin.left, w - margin.right]);
  const y = d3.scaleBand().domain(sortedEntities).range([margin.top, h - margin.bottom]).padding(0.1);
  const color = d3.scaleSequential(d3.interpolateBuPu).domain([0, 1]);

  // X Axis (Hours)
  svg.append("g")
     .attr("transform", `translate(0,${margin.top})`)
     .call(d3.axisTop(x).ticks(12).tickFormat(d => `${d}h`))
     .attr("color", "#8a8f98");

  const yAxis = svg.append('g')
     .attr("transform", `translate(${margin.left},${margin.top})`)
     .call(d3.axisLeft(y).tickSize(0));
  
  yAxis.selectAll("text")
     .attr("fill", "black");
  
  // Heatmap Cells
  svg.append("g")
    .selectAll("rect")
    .data(data)
    .join("rect")
    .attr("x", d => x(d.hour))
    .attr("y", d => y(d.entity))
    .attr("width", (w - margin.left - margin.right) / 24 - 1)
    .attr("height", y.bandwidth())
    .attr("fill", d => color(d.activity))
      .attr('rx', 5)
    .style("cursor", "pointer")
    .on("click", (e, d) => { $0.value = d.entity; });

  // Highlight rows based on selection
  svg.append("g")
     .attr("class", "highlight-overlay")
     .selectAll("rect.highlight")
     .data(sortedEntities)
     .join("rect")
     .attr("x", margin.left)
     .attr("y", d => y(d))
     .attr("width", w - margin.left - margin.right)
     .attr("height", y.bandwidth())
     .attr("fill", "none")
     .attr("stroke", "var(--accent-cyan)")
     .attr("stroke-width", 2)
     .style("display", d => d === $0.value ? "block" : "none");
  

  return svg.node();
}
)}

function _drawCoordinationMatrix(d3,$0){return(
(data, sortedEntities) => {
  const margin = { top: 40, right: 20, bottom: 20, left: 40 };
  const size = Math.min(300, sortedEntities.length * 10);
  
  const svg = d3.create("svg").attr("viewBox", [0, 0, size+margin.left, size+margin.top]).attr("width", "100%").attr("height", "100%");
  
  const scale = d3.scaleBand().domain(sortedEntities).range([0, size]).padding(0.05);
  const color = d3.scaleSequential(d3.interpolateMagma).domain([0, 1]); // Hot color scale

  const g = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);

  g.selectAll("rect")
    .data(data)
    .join("rect")
    .attr("x", d => scale(d.entity_a))
    .attr("y", d => scale(d.entity_b))
    .attr("width", scale.bandwidth())
    .attr("height", scale.bandwidth())
    .attr("fill", d => color(d.score))
    .on("click", (e, d) => { $0.value = d.entity_a; }); // Can trigger dual-select in future

  return svg.node();
}
)}

function _similaritySemanticLandscapeView(drawSemanticLandscape,semanticData){return(
drawSemanticLandscape(semanticData, 900)
)}

function _drawSemanticLandscape(d3,$0){return(
(data, w) => {
  const h = 300;

  const margin = {
    top: 20,
    right: 20,
    bottom: 40,
    left: 50
  };

  const svg = d3.create("svg")
    .attr("width", w)
    .attr("height", h);

  const xScale = d3.scaleLinear()
    .domain(d3.extent(data, d => d.x))
    .nice()
    .range([margin.left, w - margin.right]);

  const yScale = d3.scaleLinear()
    .domain(d3.extent(data, d => d.y))
    .nice()
    .range([h - margin.bottom, margin.top]);

  // Eje X
  svg.append("g")
    .attr("transform", `translate(0,${h - margin.bottom})`)
    .call(d3.axisBottom(xScale))
    .call(g => g.selectAll("text")
      .attr("fill", "black"))
    .call(g => g.selectAll("path,line")
      .attr("stroke", "black"));

  // Eje Y
  svg.append("g")
    .attr("transform", `translate(${margin.left},0)`)
    .call(d3.axisLeft(yScale))
    .call(g => g.selectAll("text")
      .attr("fill", "black"))
    .call(g => g.selectAll("path,line")
      .attr("stroke", "black"));

  // Puntos
  svg.append("g")
    .selectAll("circle")
    .data(data)
    .join("circle")
    .attr("cx", d => xScale(d.x))
    .attr("cy", d => yScale(d.y))
    .attr("r", 4)
    .attr(
      "fill",
      d => d.id === $0.value
        ? "var(--accent-orange)"
        : "#4e79a7"
    )
    .attr(
      "opacity",
      d => !$0.value || d.id === $0.value
        ? 1
        : 0.3
    )
    .style("cursor", "crosshair")
    .on("click", (e, d) => {
      $0.value = d.id;
    });

  return svg.node();
}
)}

function _TimeLineView(drawTimeline,timelineData){return(
drawTimeline(timelineData)
)}

function _drawTimeline(d3){return(
(data) => {
  const w = 800, h = 120, margin = { left: 40, right: 40, top: 20, bottom: 20 };
  const svg = d3.create("svg").attr("viewBox", [0, 0, w, h]).attr("width", "100%").attr("height", "100%");
  
  const timeExtent = d3.extent(data, d => new Date(d.timestamp));
  const x = d3.scaleTime().domain(timeExtent).range([margin.left, w - margin.right]);
  
  // Histogram of temporal density
  const bins = d3.bin().value(d => new Date(d.timestamp)).domain(x.domain()).thresholds(x.ticks(40))(data);
  const y = d3.scaleLinear().domain([0, d3.max(bins, d => d.length)]).range([h - margin.bottom, margin.top]);

  svg.append("g")
    .attr("transform", `translate(0,${h - margin.bottom})`)
    .call(d3.axisBottom(x))
    .attr("color", "var(--text-dim)");

  svg.append("g")
    .selectAll("rect")
    .data(bins)
    .join("rect")
    .attr("x", d => x(d.x0) + 1)
    .attr("y", d => y(d.length))
    .attr("width", d => Math.max(0, x(d.x1) - x(d.x0) - 1))
    .attr("height", d => h - margin.bottom - y(d.length))
    .attr("fill", "blue")
    .attr("opacity", 0.4);

  return svg.node();
}
)}

function _SequenceFlowView(drawSequenceFlow,sequenceData){return(
drawSequenceFlow(sequenceData)
)}

function _drawSequenceFlow(d3){return(
(data) => {
  const w = 800, h = 120;
  const svg = d3.create("svg").attr("viewBox", [0, 0, w, h]).attr("width", "100%").attr("height", "100%");
  
  // Minimalist representation of top 5 sequences
  const topSeqs = data.sort((a,b) => b.count - a.count).slice(0, 5);
  
  const groups = svg.selectAll("g").data(topSeqs).join("g")
    .attr("transform", (d, i) => `translate(10, ${i * 22 + 20})`);
    
  groups.append("text")
    .text(d => `${d.sequence} (${d.count}x)`)
    .attr("fill", "var(--text-dim)")
    .attr("font-size", "10px")
    .attr("font-family", "monospace");
    
  return svg.node();
}
)}

function _26(profileMap,selectedEntity){return(
profileMap.get(selectedEntity)
)}

function _27(egoData,selectedEntity){return(
egoData[selectedEntity]
)}

function _EntityInspectorView(drawEntityInspector,$0){return(
drawEntityInspector($0.value)
)}

function _drawEntityInspector(html,profileMap,egoData,d3){return(
(entityId) => {
  if (!entityId) return html`<div style="color:var(--text-dim); text-align:center; padding-top:40px; font-family:monospace;">Select an entity to view behavioral intelligence.</div>`;

  const profile = profileMap.get(entityId);
  const ego = egoData[entityId]; // Accedemos directamente a la propiedad que nos mostraste

  if (!profile || !ego) return html`<div style="color:white; font-family:monospace; padding:20px;">Data not found for: ${entityId}</div>`;

  // 1. Preparar los datos para D3 (Convertir strings a objetos)
  const nodes = ego.nodes.map(name => ({ id: name }));
  const links = ego.links.map(l => ({ ...l })); // Clonar para que D3 no ensucie la variable original

  // 2. Crear el contenedor principal
  const container = html`
    <div style="font-family: monospace; color: white;">
      <h2 style="color: var(--accent-orange); margin: 0 0 15px 0; font-size: 18px; text-transform: uppercase; letter-spacing: 1px;">${entityId}</h2>
      
      <!-- Grid de Métricas -->
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 15px;">
        <div style="background: #1c222d; padding: 8px; border: 1px solid #2a2f3a;">
          <div style="color: var(--text-dim); font-size: 9px; text-transform: uppercase;">PageRank</div>
          <div style="font-size: 14px; color: var(--accent-cyan);">${profile.pagerank.toFixed(4)}</div>
        </div>
        <div style="background: #1c222d; padding: 8px; border: 1px solid #2a2f3a;">
          <div style="color: var(--text-dim); font-size: 9px; text-transform: uppercase;">Centrality</div>
          <div style="font-size: 14px; color: var(--accent-cyan);">${profile.betweenness.toFixed(4)}</div>
        </div>
        <div style="background: #1c222d; padding: 8px; border: 1px solid #2a2f3a;">
          <div style="color: var(--text-dim); font-size: 9px; text-transform: uppercase;">In/Out Degree</div>
          <div style="font-size: 14px; color: var(--accent-green);">${profile.indegree} / ${profile.outdegree}</div>
        </div>
        <div style="background: #1c222d; padding: 8px; border: 1px solid #2a2f3a;">
          <div style="color: var(--text-dim); font-size: 9px; text-transform: uppercase;">Type</div>
          <div style="font-size: 14px; color: #fff;">${profile.type}</div>
        </div>
      </div>
      
      <h3 style="color: var(--text-dim); font-size: 10px; text-transform: uppercase; border-bottom: 1px solid var(--border); padding-bottom: 5px; margin-bottom: 10px;">Local Ego Network</h3>
      
      <!-- Contenedor del SVG -->
      <div id="ego-chart" style="height: 220px; background: #0b0e14; border: 1px solid #2a2f3a; position: relative; overflow: hidden;"></div>
    </div>
  `;

  // 3. Lógica D3 (se ejecuta después de definir el contenedor)
  const width = 330;
  const height = 220;

  const svg = d3.select(container.querySelector("#ego-chart"))
    .append("svg")
    .attr("width", "100%")
    .attr("height", "100%")
    .attr("viewBox", [0, 0, width, height]);

  // Simulación física pequeña
  const simulation = d3.forceSimulation(nodes)
    .force("link", d3.forceLink(links).id(d => d.id).distance(60))
    .force("charge", d3.forceManyBody().strength(-100))
    .force("center", d3.forceCenter(width / 2, height / 2));

  // Dibujar enlaces
  const link = svg.append("g")
    .selectAll("line")
    .data(links)
    .join("line")
    .attr("stroke", "#4e79a7")
    .attr("stroke-opacity", 0.4)
    .attr("stroke-width", d => Math.sqrt(d.weight) + 1);

  // Dibujar nodos
  const node = svg.append("g")
    .selectAll("circle")
    .data(nodes)
    .join("circle")
    .attr("r", d => d.id === entityId ? 8 : 5) // El ego es más grande
    .attr("fill", d => d.id === entityId ? "var(--accent-orange)" : "var(--accent-cyan)")
    .attr("stroke", "#0b0e14")
    .attr("stroke-width", 1.5);

  // Etiquetas de texto
  const label = svg.append("g")
    .selectAll("text")
    .data(nodes)
    .join("text")
    .text(d => d.id)
    .attr("font-size", "8px")
    .attr("fill", "white")
    .attr("text-anchor", "middle")
    .attr("dy", -10)
    .style("pointer-events", "none")
    .style("text-shadow", "1px 1px 2px #000");

  simulation.on("tick", () => {
    link
      .attr("x1", d => d.source.x)
      .attr("y1", d => d.source.y)
      .attr("x2", d => d.target.x)
      .attr("y2", d => d.target.y);

    node
      .attr("cx", d => d.x)
      .attr("cy", d => d.y);
      
    label
      .attr("x", d => d.x)
      .attr("y", d => d.y);
  });

  return container;
}
)}

function _drag(d3){return(
simulation => {
  function dragstarted(event, d) {
    if (!event.active) simulation.alphaTarget(0.3).restart();
    d.fx = d.x;
    d.fy = d.y;
  }
  function dragged(event, d) {
    d.fx = event.x;
    d.fy = event.y;
  }
  function dragended(event, d) {
    if (!event.active) simulation.alphaTarget(0);
    d.fx = null;
    d.fy = null;
  }
  return d3.drag().on("start", dragstarted).on("drag", dragged).on("end", dragended);
}
)}

function _31(htl){return(
htl.html`<style>
  :root {
    --bg-dark: #eef2f1;
    --panel-bg: #151921;
    --accent-cyan: #00f2ff;
    --accent-orange: #ff8c00;
    --accent-green: #39ff14;
    --text-dim: #8a8f98;
    --border: #2a2f3a;
  }
  body { background: var(--bg-dark); color: white; font-family: 'Inter', monospace; margin: 0; }
  
  .dashboard-grid {
    display: grid;
    grid-template-columns: 400px 1fr 350px;
    grid-template-rows: 50% 50%;
    height: 90vh;
    gap: 10px;
    padding: 10px;
  }
  
  .panel { 
    background: var(--panel-bg); 
    border: 1px solid var(--border); 
    display: flex; 
    flex-direction: column; 
    overflow: hidden; 
  }
  
  .panel-header { 
    background: #1c222d; 
    padding: 8px 12px; 
    font-size: 11px; 
    text-transform: uppercase; 
    letter-spacing: 2px; 
    color: var(--accent-cyan);
    border-bottom: 1px solid var(--border);
  }
  
  .panel-content { flex: 1; position: relative; overflow: hidden; }
  
  .timeline-bar {
    grid-column: 1 / -1;
    height: 150px;
    background: var(--panel-bg);
    border: 1px solid var(--border);
    margin: 0 10px 10px 10px;
  }
</style>`
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["semantic_projection.json", {url: new URL("./files/4346a84df35de627b89dbb4920b0170c3ec8ea9e1549d180e935aa8c5213b196e641a991be4f9eb5a46f3ad51caae231facc247249fab6b8f6cfb94ed4fb6e9c.json", import.meta.url), mimeType: "application/json", toString}],
    ["communication_sequences.json", {url: new URL("./files/f6c2f685e249b71bbf4a38ba832dc2be91163bfb5de95b895452962725ba96276fd950dad1a70a25fbefdd007b741d9aa535424eb78ce010d9aee2de34540710.json", import.meta.url), mimeType: "application/json", toString}],
    ["ego_networks.json", {url: new URL("./files/a18566e39ac1766846def2f13a330946d7cc14c15c5c7dc9fe8cd6fcb2ad792b2ccfca53803a88943f5f0f14c3afb90edeba528ea35e99948953b93d86913101.json", import.meta.url), mimeType: "application/json", toString}],
    ["communication_timeline.json", {url: new URL("./files/5d445a06ad26896932141e3c83825a74d030db5931316c4cade687a4e78e036ad4db9a1330d70fe7f9078fa83b9d4e6ed5da252f7da8d1a5c32d420d454dbb5e.json", import.meta.url), mimeType: "application/json", toString}],
    ["temporal_coordination.json", {url: new URL("./files/a92b47ed51fa0b1a12475af78edeaa01c5d7480c231daf7d859bdd7f139a96a7498780d7a1bc002b84fe40e5c32ad3d46305243718813722029a75ccd2ba2759.json", import.meta.url), mimeType: "application/json", toString}],
    ["alias_similarity_graph@7.json", {url: new URL("./files/033687f9d2a87a78215b24d6e81c6a52c195c97a6b8c42b79c2791ef87c89bb7c4dc3c485dc48f2d43044eed7de4cf098a922a01fbb9c9d75fd4f94badd7d8c0.json", import.meta.url), mimeType: "application/json", toString}],
    ["behavior_profiles@3.json", {url: new URL("./files/b12d0014d33481b7c1af604958aa13fe0071563b39f99e5244ee59b466c75458b2c6d648d2195960d72cd5285f572817e3191290ed024614b3e5cb48d5d51281.json", import.meta.url), mimeType: "application/json", toString}],
    ["temporal_heatmap@1.json", {url: new URL("./files/f12b25caf36efcf26972e842b09f9e2938d2e4bba8588c6bd65797a6333f524fd9e2b14fdb587b5436965387e538cb47707697900b9b5f81dc1976bce1dd6e73.json", import.meta.url), mimeType: "application/json", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("aliasData")).define("aliasData", ["FileAttachment"], _aliasData);
  main.variable(observer("heatmapData")).define("heatmapData", ["FileAttachment"], _heatmapData);
  main.variable(observer("timelineData")).define("timelineData", ["FileAttachment"], _timelineData);
  main.variable(observer("coordinationData")).define("coordinationData", ["FileAttachment"], _coordinationData);
  main.variable(observer("sequenceData")).define("sequenceData", ["FileAttachment"], _sequenceData);
  main.variable(observer("profileData")).define("profileData", ["FileAttachment"], _profileData);
  main.variable(observer("semanticData")).define("semanticData", ["FileAttachment"], _semanticData);
  main.variable(observer("egoData")).define("egoData", ["FileAttachment"], _egoData);
  main.define("initial selectedEntity", _selectedEntity);
  main.variable(observer("mutable selectedEntity")).define("mutable selectedEntity", ["Mutable", "initial selectedEntity"], (M, _) => new M(_));
  main.variable(observer("selectedEntity")).define("selectedEntity", ["mutable selectedEntity"], _ => _.generator);
  main.define("initial currentTimelineTime", _currentTimelineTime);
  main.variable(observer("mutable currentTimelineTime")).define("mutable currentTimelineTime", ["Mutable", "initial currentTimelineTime"], (M, _) => new M(_));
  main.variable(observer("currentTimelineTime")).define("currentTimelineTime", ["mutable currentTimelineTime"], _ => _.generator);
  main.variable(observer("getNeighbors")).define("getNeighbors", _getNeighbors);
  main.variable(observer("temporalClusteredEntities")).define("temporalClusteredEntities", ["d3","heatmapData"], _temporalClusteredEntities);
  main.variable(observer("profileMap")).define("profileMap", ["profileData"], _profileMap);
  main.variable(observer("similarityRoundView")).define("similarityRoundView", ["drawSimilarityRound","aliasData"], _similarityRoundView);
  main.variable(observer("drawSimilarityRound")).define("drawSimilarityRound", ["d3"], _drawSimilarityRound);
  main.variable(observer("similarityTemporalHeatMapView")).define("similarityTemporalHeatMapView", ["drawTemporalHeatmap","heatmapData","temporalClusteredEntities"], _similarityTemporalHeatMapView);
  main.variable(observer("drawTemporalHeatmap")).define("drawTemporalHeatmap", ["d3","mutable selectedEntity"], _drawTemporalHeatmap);
  main.variable(observer("drawCoordinationMatrix")).define("drawCoordinationMatrix", ["d3","mutable selectedEntity"], _drawCoordinationMatrix);
  main.variable(observer("similaritySemanticLandscapeView")).define("similaritySemanticLandscapeView", ["drawSemanticLandscape","semanticData"], _similaritySemanticLandscapeView);
  main.variable(observer("drawSemanticLandscape")).define("drawSemanticLandscape", ["d3","mutable selectedEntity"], _drawSemanticLandscape);
  main.variable(observer("TimeLineView")).define("TimeLineView", ["drawTimeline","timelineData"], _TimeLineView);
  main.variable(observer("drawTimeline")).define("drawTimeline", ["d3"], _drawTimeline);
  main.variable(observer("SequenceFlowView")).define("SequenceFlowView", ["drawSequenceFlow","sequenceData"], _SequenceFlowView);
  main.variable(observer("drawSequenceFlow")).define("drawSequenceFlow", ["d3"], _drawSequenceFlow);
  main.variable(observer()).define(["profileMap","selectedEntity"], _26);
  main.variable(observer()).define(["egoData","selectedEntity"], _27);
  main.variable(observer("EntityInspectorView")).define("EntityInspectorView", ["drawEntityInspector","mutable selectedEntity"], _EntityInspectorView);
  main.variable(observer("drawEntityInspector")).define("drawEntityInspector", ["html","profileMap","egoData","d3"], _drawEntityInspector);
  main.variable(observer("drag")).define("drag", ["d3"], _drag);
  main.variable(observer()).define(["htl"], _31);
  return main;
}
