import * as d3 from "npm:d3";

const NODE_COLOR = {
  Person:       "#4A81BA",
  Vessel:       "#E78523",
  Location:     "#5E9F37",
  Organization: "#C0392B",
  Group:        "#8E44AD",
};

export function drawEntityInspector(entityId, profileMap, communicationData, riskData, depth_limit = 2) {
  // 1. Validación básica
  if (!entityId || !communicationData) return null;

  const edges = communicationData.edges;
  
  // --- Lógica de filtrado BFS (Se mantiene igual) ---
  const queue = [entityId];
  const visited = new Set([entityId]);
  const distance = new Map([[entityId, 0]]);
  const edges_path = [];

  while (queue.length > 0) {
    const currentNode = queue.shift();
    const currentDist = distance.get(currentNode);
    if (currentDist >= depth_limit) continue;

    const neighbors = edges.get ? edges.get(currentNode) : edges[currentNode] || [];
    for (const neighbor of neighbors) {
      if (!visited.has(neighbor)) {
        visited.add(neighbor);
        distance.set(neighbor, currentDist + 1);
        queue.push(neighbor);
        edges_path.push({ source: currentNode, target: neighbor });
      }
    }
  }

  const nodes = Array.from(visited).map(name => ({
    id: name,
    sub_type: profileMap?.[name]?.sub_type ?? "Unknown",
  }));
  const links = edges_path.map(l => {

    const riskInfo =
      riskData?.[l.source]?.[l.target];

    return {
      ...l,

      risk_score:
        riskInfo?.risk_score ?? 0,

      risk_content:
        riskInfo?.content ?? ""
    };
  });

  const maxRisk =
  d3.max(links, d => d.risk_score) ?? 1;

  const riskColor = d3.scaleLinear()
    .domain([0, maxRisk])
    .range(["#cbd5e1", "#dc2626"]);

  const riskWidth = d3.scaleLinear()
    .domain([0, maxRisk])
    .range([1.5, 5]);
  const width = 1100;
  const height = 400;

  const svg = d3.create("svg")
    .attr("width", width)
    .attr("height", height)
    // .attr("viewBox", [0, 0, width, height])
    // .attr("style", "max-width: 100%; height: auto; background: #f8fafc; border-radius: 8px;");

  const simulation = d3.forceSimulation(nodes)
    .force("link", d3.forceLink(links).id(d => d.id).distance(60))
    .force("charge", d3.forceManyBody().strength(-120))
    .force("center", d3.forceCenter(width / 2, height / 2));

  const link = svg.append("g")
    .selectAll("line")
    .data(links)
    .join("line")
    .attr("stroke", d =>
      riskColor(d.risk_score) 
    )
    .attr("stroke-opacity", 0.85)
    .attr("stroke-width", d =>
      riskWidth(d.risk_score)
    );

    link.append("title")
        .text(d =>
      `${d.source.id ?? d.source}
      →
      ${d.target.id ?? d.target}

      Risk Score: ${d.risk_score}

      ${d.risk_content}`
        );
  const node = svg.append("g")
    .selectAll("circle")
    .data(nodes)
    .join("circle")
    .attr("r", d => d.id === entityId ? 8 : 5)
    .attr("fill", d => NODE_COLOR[d.sub_type] ?? "#94a3b8")
    .attr("stroke", d => d.id === entityId ? "#1e293b" : "#fff")
    .attr("stroke-width", d => d.id === entityId ? 2.5 : 1.5)
    .call(drag(simulation)); // Añadimos interacción de arrastre

  const labels = svg.append("g")
    .attr("font-family", "sans-serif")
    .attr("font-size", 10)
    .selectAll("text")
    .data(nodes)
    .join("text")
    .attr("dx", 10)
    .attr("dy", 4)
    .attr("fill", "#475569")
    .text(d => d.id);

 svg.append("rect")
    .attr("x", 0)
    .attr("y", 0)
    .attr("width", width)
    .attr("height", height)
    .attr("fill", "none")
    .attr("stroke", "#475569")
    .attr("stroke-width", 5);

  simulation.on("tick", () => {
    link
      .attr("x1", d => d.source.x)
      .attr("y1", d => d.source.y)
      .attr("x2", d => d.target.x)
      .attr("y2", d => d.target.y);

    node
      .attr("cx", d => d.x)
      .attr("cy", d => d.y);

    labels
      .attr("x", d => d.x)
      .attr("y", d => d.y);
  });

  function drag(simulation) {
    function dragstarted(event) {
      if (!event.active) simulation.alphaTarget(0.3).restart();
      event.subject.fx = event.subject.x;
      event.subject.fy = event.subject.y;
    }
    
    function dragged(event) {
      event.subject.fx = event.x;
      event.subject.fy = event.y;
    }
    
    function dragended(event) {
      if (!event.active) simulation.alphaTarget(0);
      event.subject.fx = null;
      event.subject.fy = null;
    }
    
    return d3.drag()
      .on("start", dragstarted)
      .on("drag", dragged)
      .on("end", dragended);
  }
  const legendWidth = 180;
  const legendHeight = 12;

  const legendX = width - 240;
  const legendY = 25;

  const defs = svg.append("defs");

  const gradient = defs.append("linearGradient")
    .attr("id", "risk-gradient")
    .attr("x1", "0%")
    .attr("x2", "100%")
    .attr("y1", "0%")
    .attr("y2", "0%");

  const steps = 10;

  for (let i = 0; i <= steps; i++) {

    const t = i / steps;

    gradient.append("stop")
      .attr("offset", `${t * 100}%`)
      .attr("stop-color", riskColor(
        t * maxRisk
      ));
  }

  /*
  ------------------------------------------
  Legend group
  ------------------------------------------
  */

  const legend = svg.append("g")
    .attr(
      "transform",
      `translate(${legendX}, ${legendY})`
    );

  /*
  ------------------------------------------
  Title
  ------------------------------------------
  */

  legend.append("text")
    .attr("x", 0)
    .attr("y", -8)
    .attr("font-size", 11)
    .attr("font-weight", 600)
    .attr("fill", "#334155")
    .text("Risk Score");

  /*
  ------------------------------------------
  Gradient bar
  ------------------------------------------
  */

  legend.append("rect")
    .attr("width", legendWidth)
    .attr("height", legendHeight)
    .attr("rx", 3)
    .attr("fill", "url(#risk-gradient)")
    .attr("stroke", "#cbd5e1");

  /*
  ------------------------------------------
  Axis scale
  ------------------------------------------
  */

  const legendScale = d3.scaleLinear()
    .domain([0, maxRisk])
    .range([0, legendWidth]);

  const legendAxis = d3.axisBottom(legendScale)
    .ticks(4)
    .tickSize(4);

  legend.append("g")
    .attr(
      "transform",
      `translate(0, ${legendHeight})`
    )
    .call(legendAxis)
    .call(g => g.select(".domain").remove())
    .call(g =>
      g.selectAll("text")
        .attr("font-size", 9)
        .attr("fill", "#475569")
    );
  return svg.node();
}