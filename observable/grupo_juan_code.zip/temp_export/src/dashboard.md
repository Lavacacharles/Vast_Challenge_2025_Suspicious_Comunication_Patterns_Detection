---
title: Intelligence Coordination Dashboard
---

<div class="hero">
  <h1 style="font-size: 120%;">
    Illegal Coordination Network Analysis
  </h1>
</div>

---

```js
import * as d3 from "npm:d3";
import * as Inputs from "npm:@observablehq/inputs";

import {
  aliasData,
  profileData,
  communicationData,
  riskData,
  timelineData,
  timelineEntitiesData
} from "./components/data_load.js";

import {
  drawSimilarityRound
} from "./components/round.js";

import {
  drawEntityInspector
} from "./components/ego_network.js";

import {
  drawSimilarityNetwork
} from "./components/similarity_network.js";

import {
  drawTemporalActivity
} from "./components/timeline.js";
```

```js
/*
====================================================
GLOBAL INVESTIGATION STATE
====================================================
*/

const allEntities = aliasData.nodes.map(d => d.id);

const selectedEntities = view(
  Inputs.select(
    allEntities,
    {
      label: "Investigation Target",
      multiple: true,
      value: ["Mako"]
    }
  )
);

const selectedCluster = view(
  Inputs.select(
    [
      "All",
      "Person",
      "Vessel",
      "Location",
      "Organization",
      "Group"
    ],
    {
      label: "Entity Type Filter",
      value: "All"
    }
  )
);

const selectedDepth = view(
  Inputs.range(
    [1, 6],
    {
      label: "Ego Network Depth",
      step: 1,
      value: 2
    }
  )
);

const selectedRiskThreshold = view(
  Inputs.range(
    [0, 1],
    {
      label: "Risk Threshold",
      step: 0.05,
      value: 0
    }
  )
);

const selectedTimeRange = view(
  Inputs.range(
    [1, 14],
    {
      label: "Timeline Window (Days)",
      step: 1,
      value: 14
    }
  )
);
```

```js
/*
====================================================
FILTERED DATA
====================================================
*/

const filteredAliasData = {
  nodes:
    selectedCluster === "All"
      ? aliasData.nodes
      : aliasData.nodes.filter(
          d => d.type === selectedCluster
        ),

  links:
    aliasData.links.filter(l => {

      const source =
        typeof l.source === "object"
          ? l.source.id
          : l.source;

      const target =
        typeof l.target === "object"
          ? l.target.id
          : l.target;

      const sourceNode = aliasData.nodes.find(
        d => d.id === source
      );

      const targetNode = aliasData.nodes.find(
        d => d.id === target
      );

      if (selectedCluster === "All") return true;

      return (
        sourceNode?.type === selectedCluster ||
        targetNode?.type === selectedCluster
      );
    })
};
```

```js
display(html`
<div class="global-legend">

  <div class="legend-section">
    <span class="legend-title">Entity Types</span>

    <div class="legend-row">
      <span class="dot person"></span>Person
    </div>

    <div class="legend-row">
      <span class="dot vessel"></span>Vessel
    </div>

    <div class="legend-row">
      <span class="dot location"></span>Location
    </div>

    <div class="legend-row">
      <span class="dot organization"></span>Organization
    </div>

    <div class="legend-row">
      <span class="dot group"></span>Group
    </div>
  </div>

  <div class="legend-section">
    <span class="legend-title">Similarity</span>

    <div class="legend-row">
      <span class="line high"></span>High
    </div>

    <div class="legend-row">
      <span class="line medium"></span>Medium
    </div>

    <div class="legend-row">
      <span class="line low"></span>Low
    </div>
  </div>

</div>
`)
```

```js
display(html`

<div class="dashboard-grid">

  <!-- ================================================= -->
  <!-- TOPOLOGY OVERVIEW -->
  <!-- ================================================= -->

  <section class="panel topology-panel">

    <div class="panel-header">
      Coordination Topology Overview
    </div>

    <div class="panel-description">
      Detect suspicious coordination structures and
      operational clusters.
    </div>

    ${drawSimilarityRound(
      filteredAliasData,
      1100,
      600
    )}

  </section>


  <!-- ================================================= -->
  <!-- EGO NETWORK -->
  <!-- ================================================= -->

  <section class="panel ego-panel">

    <div class="panel-header">
      Operational Ego Expansion
    </div>

    <div class="panel-description">
      Explore operational proximity and communication risk.
    </div>

    ${
      selectedEntities.length > 0
      ? drawEntityInspector(
          selectedEntities[0],
          profileData,
          communicationData,
          riskData,
          selectedDepth
        )
      : html`<div class="empty-state">Select an entity</div>`
    }

  </section>


  <!-- ================================================= -->
  <!-- ALIAS NETWORK -->
  <!-- ================================================= -->

  <section class="panel similarity-panel">

    <div class="panel-header">
      Alias Corroboration Network
    </div>

    <div class="panel-description">
      Identify pseudonym candidates and semantic overlap.
    </div>

    ${drawSimilarityNetwork(
      filteredAliasData,
      650,
      500
    )}

  </section>


  <!-- ================================================= -->
  <!-- TIMELINE -->
  <!-- ================================================= -->

  <section class="panel timeline-panel">

    <div class="panel-header">
      Temporal Coordination Analysis
    </div>

    <div class="panel-description">
      Validate synchronized operational behavior.
    </div>

    ${
      selectedEntities.length > 0
      ? drawTemporalActivity(
          selectedEntities,
          timelineData,
          timelineEntitiesData
        )
      : html`<div class="empty-state">Select entities</div>`
    }

  </section>

</div>

`)
```
--- 
<style>

:root {
  --bg: #f8fafc;
  --panel: white;
  --border: #e2e8f0;
  --text: #0f172a;
  --muted: #64748b;
}

/* ==================================================== */
/* PAGE */
/* ==================================================== */

body {
  background: var(--bg);
}

/* ==================================================== */
/* GRID */
/* ==================================================== */

.dashboard-grid {

  display: grid;

  grid-template-columns:
    1fr 1fr;

  grid-template-rows:
    auto auto auto;

  gap: 18px;

  align-items: start;
}

/* ==================================================== */
/* PANELS */
/* ==================================================== */

.panel {

  background: var(--panel);

  border: 1px solid var(--border);

  border-radius: 14px;

  padding: 14px;

  box-shadow:
    0 1px 2px rgba(0,0,0,0.04);

  overflow: hidden;
}

.topology-panel {
  grid-column: 1 / span 2;
}

.timeline-panel {
  grid-column: 1 / span 2;
}

/* ==================================================== */
/* TYPOGRAPHY */
/* ==================================================== */

.panel-header {

  font-size: 16px;

  font-weight: 700;

  color: var(--text);

  margin-bottom: 4px;
}

.panel-description {

  font-size: 12px;

  color: var(--muted);

  margin-bottom: 10px;
}

/* ==================================================== */
/* LEGEND */
/* ==================================================== */

.global-legend {

  display: flex;

  gap: 40px;

  margin-bottom: 16px;

  padding: 12px 16px;

  background: white;

  border: 1px solid #e2e8f0;

  border-radius: 12px;
}

.legend-section {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.legend-title {
  font-size: 12px;
  font-weight: 700;
  color: #334155;
}

.legend-row {
  display: flex;
  align-items: center;
  gap: 10px;

  font-size: 12px;
}

.dot {

  width: 10px;
  height: 10px;

  border-radius: 50%;
}

.person { background: #4A81BA; }
.vessel { background: #E78523; }
.location { background: #5E9F37; }
.organization { background: #C0392B; }
.group { background: #8E44AD; }

.line {
  width: 24px;
  height: 3px;
  display: inline-block;
}

.high {
  background: #810f7c;
}

.medium {
  background: #9ebcda;
}

.low {
  background: #8c96c6;
}

/* ==================================================== */
/* EMPTY STATE */
/* ==================================================== */

.empty-state {

  display: flex;

  align-items: center;

  justify-content: center;

  height: 400px;

  color: #94a3b8;

  font-size: 14px;
}

</style>